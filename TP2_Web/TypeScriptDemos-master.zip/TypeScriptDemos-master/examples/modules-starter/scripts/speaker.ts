export class Speaker {
  constructor(public firstName: string, 
                public lastName: string) {}

}

