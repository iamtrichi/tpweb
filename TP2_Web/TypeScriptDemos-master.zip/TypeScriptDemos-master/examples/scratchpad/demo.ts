class Person {
    constructor(public name: string,
                private age: number) { }
}

let person = new Person('John', 67);
 




