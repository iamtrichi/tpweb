﻿export class Constants {
    static get ROUTING_NUMBER(): string { return '1231A4433Y2'; }
    static get BANK_NUMBER(): number { return 100008374; }
}