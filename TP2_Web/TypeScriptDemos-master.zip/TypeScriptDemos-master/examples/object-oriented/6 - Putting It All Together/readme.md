## Putting It All Together

Thanks for checking out the `Creating Object-Oriented TypeScript Code` course on Pluralsight!

This module of the course provides a review of the key topics so there's no code to show.
If you want the final code solution for the course go to the
`object-oriented/solution` directory.
