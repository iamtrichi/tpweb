export enum AccountType {
    Checking,
    Savings
}