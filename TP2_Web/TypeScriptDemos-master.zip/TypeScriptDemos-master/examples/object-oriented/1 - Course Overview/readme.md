## Course Overview

This is the course overview module so there's no code here. To run the code in the
course modules you'll need to have the following installed though:

1. Node.js LTS (https://nodejs.org)
2. A code editor. I use VS Code (https://code.visualstudio.com) throughout the course.
