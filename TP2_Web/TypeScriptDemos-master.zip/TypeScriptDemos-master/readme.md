# TypeScript Examples

## Running the Application

1. Install Node.js from http://nodejs.org

1. Run `npm install` 

1. Run `npm start` to compile the TypeScript and start the server 
